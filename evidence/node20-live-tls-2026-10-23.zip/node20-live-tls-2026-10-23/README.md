# Node.js live HTTPS test: eMudhra test endpoint, 23 October 2026

Evidence for the live HTTPS test in "Official Node 20 Docker Images Still Trust
a Compromised eMudhra Certificate Chain — Rebuilding Doesn't Fix It",
published in CytherAI's trust-revocation-research repository.

On 2026-10-23, the Node.js runtimes in two official images made HTTPS GET
requests, with certificate verification on, to two targets:

- the disclosure site's test endpoint,
  https://dv-g3b-noct-emudhra.we-have-a-problem.com/
- https://example.com/, as a control

The images were pinned by index digest:

- `node:20-slim@sha256:2cf067cfed83d5ea958367df9f966191a942351a2df77d6f0193e162b5febfc0`
  (Node.js 20.20.2). This is the digest recorded in the Node.js 20 evidence
  package.
- `node:22.23.4-bookworm-slim@sha256:de170b39439eb0e5a3444ad7d60b015614a381e10fecae2e30ec9e735122f38d`
  (Node.js 22.23.4)

| Run | Platform | Cases run (UTC) |
|---|---|---|
| `runs/tls-node-runtime-20261023T061155Z` | linux/arm64 | 2026-10-23 06:13:57 to 06:14:01 |
| `runs/tls-node-runtime-20261023T061441Z` | linux/amd64, emulated on Apple Silicon | 2026-10-23 06:16:20 to 06:16:26 |

## Results (identical on both platforms)

| Case | Runtime | Target | Result |
|---|---|---|---|
| node20-control | Node.js 20.20.2 | example.com | ACCEPT, HTTP 200 |
| node22-control | Node.js 22.23.4 | example.com | ACCEPT, HTTP 200 |
| node20-default | Node.js 20.20.2 | test endpoint | ACCEPT: TLS 1.3, verified chain, HTTP 200 |
| node20-forced-bundled | Node.js 20.20.2, `--use-bundled-ca` | test endpoint | ACCEPT, HTTP 200 |
| node22-default | Node.js 22.23.4 | test endpoint | REJECT, `CERT_REVOKED` |
| node20-openssl-control | Node.js 20.20.2, `--use-openssl-ca` | example.com | REJECT, `UNABLE_TO_GET_ISSUER_CERT_LOCALLY` |
| node20-openssl | Node.js 20.20.2, `--use-openssl-ca` | test endpoint | REJECT, `UNABLE_TO_GET_ISSUER_CERT_LOCALLY` |

- In the accepted connections to the test endpoint, the leaf certificate
  (SHA-256 `0C:BF:E2:2B:82:43:85:82:3F:D3:BF:4B:E4:D1:31:E8:90:13:42:93:3A:7F:EE:F1:CF:8B:31:10:B8:E4:4A:70`)
  is the leaf of `chains/dv-g3b-noct-emudhra.we-have-a-problem.com.pem` in
  the Node.js 20 evidence package. Its issuer is EM DV TLS CA - G3B.
- Node.js 22.23.4 rejects chains through the eight compromised intermediates
  by their public keys and reports the failure as `CERT_REVOKED`
  (nodejs/node#66871). EM DV TLS CA - G3B is one of them.
- node:20-slim ships no system CA bundle. With `--use-openssl-ca`, Node.js 20
  rejects every chain, the control included. That pair of cases says nothing
  about distrust.

## Files

- `run_node_tls_probe.sh`: the script that produced both runs
- `runs/*/`: each run's output, unmodified:
  - `node_tls_probe.js`: the probe that ran
  - `results.jsonl`: one line per case
  - `environment.txt`: Docker version, platform and image references
  - `SHA256SUMS`: hashes of the three files above
- `SHA256SUMS`: hashes of every file in this package

In `environment.txt`, the `PLATFORM` field shows Docker's default platform for
the multi-platform image, not the variant that ran. In the linux/amd64 run it
reads linux/arm64. The architecture each case actually ran is the `arch` field
of its line in `results.jsonl` (`arm64` or `x64`). The repository's current
script no longer records that field.

## Verify

    sha256sum -c SHA256SUMS
    (cd runs/tls-node-runtime-20261023T061155Z && sha256sum -c SHA256SUMS)
    (cd runs/tls-node-runtime-20261023T061441Z && sha256sum -c SHA256SUMS)

To repeat the test, run `scripts/run_node_tls_probe.sh` from the repository
(this needs Docker). The endpoint serves whatever chain the disclosure site has
configured at the time, so each run is a point-in-time record.

## License

This README and `runs/*/results.jsonl` and `environment.txt`: CC BY 4.0,
CytherAI. `run_node_tls_probe.sh` and `node_tls_probe.js`: Apache-2.0,
CytherAI. The certificate fields recorded in the results are factual data from
the TLS connections.
