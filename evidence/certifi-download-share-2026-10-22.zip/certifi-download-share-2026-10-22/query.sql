SELECT date, version, sum(count)
FROM pypi.pypi_downloads_per_day_by_version_by_installer_by_type
WHERE project = 'certifi' AND date BETWEEN '2026-10-13' AND '2026-10-22' AND installer != 'bandersnatch'
GROUP BY date, version
ORDER BY date, version
FORMAT TSV
