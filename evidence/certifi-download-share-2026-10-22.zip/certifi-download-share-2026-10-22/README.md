# certifi download share: the eMudhra root, 13–22 October 2026

Evidence for `research/certifi-download-share.md` in CytherAI's
trust-revocation-research repository.

Produced by `scripts/certifi_download_share.py 2026-10-13 2026-10-22` at the
time in `RETRIEVED_AT`. All files except this README and `SHA256SUMS` are that
run's unmodified output.

- `query.sql`: the query sent to ClickPy's public PyPI download statistics
  (https://sql-clickhouse.clickhouse.com, table
  `pypi.pypi_downloads_per_day_by_version_by_installer_by_type`). It excludes
  the bandersnatch mirror client.
- `clickpy-daily.tsv`: certifi downloads per day and version, as returned.
- `certifi-version-inventory.tsv`: one row for each of the 77 versions
  downloaded in the period, with:
  - the release file checked: the wheel if one was published, otherwise the
    sdist;
  - its SHA-256, which matches PyPI's digest;
  - the number of certificates in its `cacert.pem`;
  - whether emSign ECC Root CA - G3 is present. The root is identified by the
    SHA-256 of its DER encoding,
    `86A1ECBA089C4A8D3BBE2734C612BA341D813E043CF9E8A862CD5C57A36BBE6B`.
- `download-share.tsv`: per day, the total downloads, the downloads of
  releases containing the root, and the affected share. Affected downloads are
  split between the latest such release (2026.7.22) and older ones. The
  downloads of the fixed releases (2026.10.18 and 2026.10.19) are counted
  separately.
- `affected-by-release-age.tsv`: per day, affected downloads by how old the
  release was on the download day.
- `RETRIEVED_AT`: when the data was retrieved, in UTC.

## Verify and reproduce

    sha256sum -c SHA256SUMS
    python3 -I scripts/certifi_download_share.py 2026-10-13 2026-10-22 <new_dir>

The counts are those ClickPy returned at `RETRIEVED_AT`. A later run that
returns different counts for the same days should be reported as a revision of
the source data.

## License

This README and the TSV results: CC BY 4.0, CytherAI. `query.sql`: Apache-2.0,
CytherAI. The download counts are factual data from PyPI's public download
statistics, retrieved through ClickPy. No third-party files are included; the
certifi releases are identified by their SHA-256 only.
