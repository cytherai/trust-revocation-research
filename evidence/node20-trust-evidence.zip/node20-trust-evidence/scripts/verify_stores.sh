#!/usr/bin/env bash
# Verify the never-CT-logged test chain against each trust store, the way a
# client that ignores revocation and CT would: leaf first, the rest untrusted.
# Usage: verify_stores.sh <chains_dir> <store.pem>...
set -u
chains="$1"; shift
work=$(mktemp -d)
for chain in "$chains"/dv-g3b-noct-emudhra.we-have-a-problem.com.pem "$chains"/dv-g3b-aaa-noct-emudhra.we-have-a-problem.com.pem; do
  host=$(basename "$chain" .pem)
  awk -v d="$work" '/BEGIN CERT/{n++} {print > (d "/c" n ".pem")}' "$chain"
  cat "$work"/c[2-9].pem > "$work/untrusted.pem"
  for store in "$@"; do
    r=$(openssl verify -CAfile "$store" -untrusted "$work/untrusted.pem" \
        -purpose sslserver -verify_hostname "${host}" "$work/c1.pem" 2>&1 | tail -1)
    case "$r" in *": OK") v=ACCEPTED ;; *) v="rejected (${r##*error })" ;; esac
    printf '%-34s %-40s %s\n' "${host%%-emudhra*}" "$(basename "$(dirname "$store")")/$(basename "$store")" "$v"
  done
  rm -f "$work"/c*.pem
done
rm -rf "$work"
