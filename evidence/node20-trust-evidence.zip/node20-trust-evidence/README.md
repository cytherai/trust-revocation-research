# Node.js 20 trust evidence: eMudhra intermediate CA compromise

Evidence for "Official Node 20 Docker Images Still Trust a Compromised eMudhra
Certificate Chain — Rebuilding Doesn't Fix It", published in CytherAI's
trust-revocation-research repository.

All files except this README and SHA256SUMS are unmodified copies of files in
CytherAI's evidence snapshot of 2026-10-22 (zip SHA-256
6f5f468885c921d9b4be8b3ca881d568384d8c2097caef6b822e10724648435c). The files
under results/ keep only their lines about Node.js, each line unmodified. The
full snapshot will be published after a coordinated disclosure window.

- `RETRIEVED_AT`: when the Docker Hub state was recorded (UTC). Chains are
  verified as of this time.
- `chains/`: the two test chains from the disclosure site, whose leaves were
  never logged to Certificate Transparency. Source:
  https://emudhra.we-have-a-problem.com/chains.zip (SHA-256
  7b949956955fc501a30f4d98d2f513d34c0bbbe92e29a968194c96e097ce2345)
- `stores/node-v*/roots.pem`: Node.js built-in roots at 20.20.2, 22.22.0,
  22.23.4 and 24.22.1
- `sources/`: `src/node_root_certs.h` at v20.20.2, v22.23.4 and v24.22.1
- `results/openssl-verify.txt`: OpenSSL output for each chain and store
- `results/fingerprints.txt`: SHA-256 fingerprints of the chain certificates,
  and of emSign ECC Root CA - G3 in each store
- `results/registry-state.txt`: Docker Hub digests, push dates and Node.js
  versions for node:20, 20-slim, 20-alpine, 22, 24 and 26
- `scripts/verify_stores.sh`: the script used on 2026-10-22

## Reproduce

Needs OpenSSL 3 or later. LibreSSL, which is macOS's /usr/bin/openssl, cannot
run the check.

    sha256sum -c SHA256SUMS
    bash scripts/verify_stores.sh chains stores/*/*

The test leaves expire on 2027-05-05. After that, use `scripts/verify_stores.sh`
from the repository, which verifies as of `RETRIEVED_AT`.

## License

This README and `results/`: CC BY 4.0, CytherAI. `scripts/verify_stores.sh`:
Apache-2.0, CytherAI. Third-party files keep their own terms: the test chains
come from the disclosure site, which publishes no license; the Node.js files are
under the Node.js license, and the certificate data in them comes from Mozilla
NSS under MPL-2.0. See THIRD_PARTY_NOTICES.md in the repository.
